<?php
include 'db_config.php';
include 'header.php';

// Lấy tổng doanh thu từ TẤT CẢ đơn hàng (không phân biệt status)
$q_total_revenue = "SELECT SUM(total_amount) AS total_revenue FROM orders";
$result_revenue = mysqli_query($conn, $q_total_revenue);

if (!$result_revenue) {
    $total_revenue = 0;
} else {
    $row_revenue = mysqli_fetch_assoc($result_revenue);
    $total_revenue = $row_revenue['total_revenue'] ?? 0;
}

// Lấy tổng số sản phẩm bán ra từ TẤT CẢ đơn hàng (không phân biệt status)
$q_total_products = "SELECT SUM(quantity) AS total_products FROM order_items";
$result_products = mysqli_query($conn, $q_total_products);

if (!$result_products) {
    $total_products = 0;
} else {
    $row_products = mysqli_fetch_assoc($result_products);
    $total_products = $row_products['total_products'] ?? 0;
}

mysqli_close($conn);
?>

<link rel="stylesheet" href="css/admin_dashboard_revenue.css">

<div class="dashboard-container">
    <div class="dashboard-header">
        <div class="header-content">
            <div class="header-icon">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="header-text">
                <h1><i class="fas fa-chart-bar"></i> Bảng Điều Khiển Doanh Thu</h1>
                <p><i class="fas fa-chart-pie"></i> Thống kê doanh thu và sản phẩm từ tất cả đơn hàng</p>
            </div>
        </div>
        
        <!-- Button làm mới dữ liệu -->
        <button class="refresh-btn" onclick="refreshData()">
            <i class="fas fa-sync-alt"></i>
            Làm Mới Dữ Liệu
        </button>
    </div>

    <div class="stats-grid">
        <!-- Doanh thu -->
        <div class="stat-card revenue">
            <div class="stat-icon">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <h2 class="stat-title"><i class="fas fa-dollar-sign"></i> Tổng Doanh Thu</h2>
            <div class="stat-value" id="revenueValue">
                <?= number_format($total_revenue) ?>
            </div>
            <div class="stat-unit"><i class="fas fa-wallet"></i> VND</div>
            <div class="stat-trend trend-positive">
                <i class="fas fa-arrow-up"></i> Tổng doanh thu từ tất cả đơn hàng
            </div>
        </div>

        <!-- Số sản phẩm bán ra -->
        <div class="stat-card products">
            <div class="stat-icon">
                <i class="fas fa-shopping-bag"></i>
            </div>
            <h2 class="stat-title"><i class="fas fa-cube"></i> Số Sản Phẩm Bán Ra</h2>
            <div class="stat-value" id="productsValue">
                <?= number_format($total_products) ?>
            </div>
            <div class="stat-unit"><i class="fas fa-boxes"></i> sản phẩm</div>
            <div class="stat-trend trend-positive">
                <i class="fas fa-arrow-up"></i> Sản phẩm đã đặt hàng
            </div>
        </div>
    </div>

    <div class="dashboard-footer">
        <p><i class="far fa-clock"></i> Cập nhật lần cuối: <?= date('d/m/Y H:i:s') ?></p>
        <?php if ($total_revenue == 0 && $total_products == 0): ?>
            <p class="no-data-warning">
                <i class="fas fa-exclamation-triangle"></i> Chưa có dữ liệu đơn hàng
            </p>
        <?php else: ?>
            <p class="data-success">
                <i class="fas fa-check-circle"></i> Đang hiển thị dữ liệu thực tế
            </p>
        <?php endif; ?>
    </div>
</div>

<script src="js/admin_dashboard_revenue.js"></script>

<?php include 'footer.php'; ?>