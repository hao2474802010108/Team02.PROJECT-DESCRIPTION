// Revenue Dashboard JavaScript với Font Awesome
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Khởi tạo Revenue Dashboard...');
    
    // Khởi tạo tất cả tính năng
    initializeCountUp();
    initializeHoverEffects();
    initializeClickEffects();
    initializeAutoRefresh();
    
    console.log('✅ Revenue Dashboard đã sẵn sàng!');
});

// Hiệu ứng count up cho các số
function initializeCountUp() {
    const elements = [
        { id: 'revenueValue', duration: 2500, delay: 500 },
        { id: 'productsValue', duration: 2000, delay: 800 }
    ];

    elements.forEach(({ id, duration, delay }) => {
        const element = document.getElementById(id);
        if (element) {
            const value = parseNumber(element.textContent);
            if (value > 0) {
                element.textContent = '0';
                setTimeout(() => {
                    animateCountUp(element, 0, value, duration);
                }, delay);
            }
        }
    });
}

// Hàm count up animation
function animateCountUp(element, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const value = Math.floor(progress * (end - start) + start);
        element.textContent = formatNumber(value);
        
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// Định dạng số với dấu phân cách
function formatNumber(number) {
    return new Intl.NumberFormat('vi-VN').format(number);
}

// Parse số từ chuỗi
function parseNumber(text) {
    return parseInt(text.replace(/[^\d]/g, '')) || 0;
}

// Hiệu ứng hover
function initializeHoverEffects() {
    const statCards = document.querySelectorAll('.stat-card');
    
    statCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = '0 12px 25px rgba(0, 0, 0, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        });
    });
}

// Hiệu ứng click
function initializeClickEffects() {
    const statCards = document.querySelectorAll('.stat-card');
    
    statCards.forEach(card => {
        card.style.cursor = 'pointer';
        card.addEventListener('click', function(event) {
            createRippleEffect(event, this);
            animateCardClick(this);
        });
    });
}

// Animation click card
function animateCardClick(card) {
    card.style.transform = 'scale(0.95)';
    setTimeout(() => {
        card.style.transform = 'scale(1)';
    }, 150);
}

// Hiệu ứng ripple khi click
function createRippleEffect(event, element) {
    const ripple = document.createElement('div');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;

    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: rgba(229, 0, 16, 0.3);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s linear;
        pointer-events: none;
        z-index: 1;
    `;

    element.style.position = 'relative';
    element.appendChild(ripple);

    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Tự động refresh
function initializeAutoRefresh() {
    // Refresh mỗi 2 phút
    setInterval(() => {
        refreshData();
    }, 120000);
}

// Refresh dữ liệu
function refreshData() {
    console.log('🔄 Đang làm mới dữ liệu...');
    showLoading();
    
    setTimeout(() => {
        location.reload();
    }, 1000);
}

// Hiển thị loading
function showLoading() {
    const refreshBtn = document.querySelector('.refresh-btn');
    if (refreshBtn) {
        const originalText = refreshBtn.innerHTML;
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang làm mới...';
        refreshBtn.disabled = true;
        
        setTimeout(() => {
            refreshBtn.innerHTML = originalText;
            refreshBtn.disabled = false;
        }, 1000);
    }
    
    const cards = document.querySelectorAll('.stat-card');
    cards.forEach(card => {
        const valueElement = card.querySelector('.stat-value');
        if (valueElement) {
            const originalText = valueElement.textContent;
            valueElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            valueElement.style.fontSize = '2rem';
            
            setTimeout(() => {
                valueElement.textContent = originalText;
                valueElement.style.fontSize = '';
            }, 800);
        }
    });
}